#!/usr/bin/env python3
"""
Start script for the Reddit Bot backend
This file can be used for deployment or local development
"""

import os
import sys
from main import main

if __name__ == "__main__":
    # Set up environment for deployment
    if os.environ.get("VERCEL"):
        # Running on Vercel
        print("Starting Reddit Bot on Vercel...")
    else:
        # Running locally
        print("Starting Reddit Bot locally...")
    
    try:
        main()
    except KeyboardInterrupt:
        print("\nBot stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"Error starting bot: {e}")
        sys.exit(1) 